/**
 * 
 */
/**
 * 
 */
module Herencia3 {
}