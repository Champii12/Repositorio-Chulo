import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Swingforma1 {

    private JTextArea calculadora;
    private JTextField resultado;
    private JButton Raiz;
    private JButton CE;
    private JButton CL;
    private JButton mas_menos;
    private JButton siete;
    private JButton ocho;
    private JButton nueve;
    private JButton cuatro;
    private JButton cinco;
    private JButton seis;
    private JButton X;
    private JButton uno;
    private JButton dos;
    private JButton tres;
    private JButton menos;
    private JButton cero;
    private JButton punto;
    private JButton igual;
    private JButton mas;
    private JPanel panel_Principal;
    private JButton barra;
    private JPanel textoCalculadora;

    private double num1;
    private double num2;
    private String operador;

    public Swingforma1() {

        JFrame frame = new JFrame("Calculadora");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(panel_Principal);
        frame.pack();
        frame.setVisible(true);
        frame.setMinimumSize(new Dimension(500,600));
        frame.setLocationRelativeTo(null);


        inicializarComponentes();
    }

    private void inicializarComponentes() {

        resultado.setEditable(false);
        resultado.setHorizontalAlignment(SwingConstants.RIGHT);
        resultado.setText("0");

        ActionListener listener = new BotonListener();

        mas.addActionListener(listener);
        menos.addActionListener(listener);
        X.addActionListener(listener);
        barra.addActionListener(listener);
        nueve.addActionListener(listener);
        ocho.addActionListener(listener);
        siete.addActionListener(listener);
        seis.addActionListener(listener);
        cinco.addActionListener(listener);
        cuatro.addActionListener(listener);
        tres.addActionListener(listener);
        dos.addActionListener(listener);
        uno.addActionListener(listener);
        cero.addActionListener(listener);
        punto.addActionListener(listener);
        igual.addActionListener(listener);
        CE.addActionListener(listener);
        CL.addActionListener(listener);
        mas_menos.addActionListener(listener);
        Raiz.addActionListener(listener);
    }


    private class BotonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String texto = e.getActionCommand();
            manejarBoton(texto);
        }
    }

    private void manejarBoton(String texto) {
        switch (texto) {
            case "C":
                resultado.setText("0");
                break;
            case "^":
                operador = "^"; // Asignar el operador de potencia
                num1 = Double.parseDouble(resultado.getText());
                resultado.setText("0");
                break;

            case "CL":
                resultado.setText("0");
                num1 = num2 = 0;
                operador = null;
                break;
            case "+ / -":
                if (!resultado.getText().equals("0")) {
                    double valor = Double.parseDouble(resultado.getText());
                    valor = valor * -1;
                    resultado.setText(String.valueOf(valor));
                }
                break;

            case "=":
                calcular();
                break;
            case "+":
                operador = "+";
                num1 = Double.parseDouble(resultado.getText());
                resultado.setText("0");
                break;
            case "-":
                operador = "-";
                num1 = Double.parseDouble(resultado.getText());
                resultado.setText("0");
                break;
            case "X":
                operador = "*";
                num1 = Double.parseDouble(resultado.getText());
                resultado.setText("0");
                break;
            case "/":
                operador = "/";
                num1 = Double.parseDouble(resultado.getText());
                resultado.setText("0");
                break;
            case "√":
                double valor = Double.parseDouble(resultado.getText());
                if (valor > 0){
                    double raizCuadrada = Math.sqrt(valor);
                    resultado.setText(String.valueOf(raizCuadrada));
                }else{
                    resultado.setText("Syntax error");
                    JOptionPane.showMessageDialog(panel_Principal, "No puedes hacer raices negativas.");
                }
                break;
            default:
                if (resultado.getText().equals("0")) {
                    resultado.setText(texto);
                } else {
                    resultado.setText(resultado.getText() + texto);
                }
                break;
        }
    }


    private void calcular() {
        if (operador != null) {
            num2 = Double.parseDouble(resultado.getText());
            double resultadoFinal = 0;

            switch (operador) {
                case "+":
                    resultadoFinal = num1 + num2;
                    break;
                case "-":
                    resultadoFinal = num1 - num2;
                    break;
                case "*":
                    resultadoFinal = num1 * num2;
                    break;
                case "/":
                    if (num2 != 0) {
                        resultadoFinal = num1 / num2;
                    } else {
                        resultado.setText("Syntax error");
                        JOptionPane.showMessageDialog(panel_Principal, "No puedes ser 0 el divisor.");
                        return;
                    }
                    break;
                case "^": // Caso de potencia
                    resultadoFinal = Math.pow(num1, num2); // Calcula la potencia
                    break;
            }
            resultado.setText(String.valueOf(resultadoFinal)); // Mostrar el resultado en el JTextField
            operador = null; // Reiniciar operador
        }
    }

    public static void main(String[] args) {
        new Swingforma1(); // Crear y mostrar la calculadora
    }
}