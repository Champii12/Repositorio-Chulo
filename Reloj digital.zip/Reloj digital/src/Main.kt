import java.time.LocalTime
import java.time.format.DateTimeFormatter


fun main() {


}