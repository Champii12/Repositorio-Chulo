import java.awt.event.*;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import javax.swing.*;


public class relojDigital {

    private JPanel panel;
    private JLabel horas;
    private JLabel minutos;
    private JLabel segundos;
    private JLabel dosPuntos1;
    private JLabel dosPuntos2;
    private JLabel diaSemana;
    private JLabel diaNumero;
    private JLabel mes;
    private JLabel anyo;

    public relojDigital(){

        JFrame jf = new JFrame("Reloj digital");

        jf.setContentPane(panel);

        Timer tiempo = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarReloj();
            }
        });
        tiempo.start();

        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.pack();
        jf.setVisible(true);

    }

    private void actualizarReloj(){

        // Hora

        LocalTime tiempoLocal = LocalTime.now();
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("HH:mm:ss");
        String[] tiempoFormato = tiempoLocal.format(formato).split(":");

        horas.setText(tiempoFormato[0]);
        minutos.setText(tiempoFormato[1]);
        segundos.setText(tiempoFormato[2]);

        // Fecha

        LocalDate diaLocal = LocalDate.now();
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("EEEE d MMM yyyy", new Locale("es", "ES"));
        String fechaFormato = diaLocal.format(formatoFecha);

        String[] separadorFecha = fechaFormato.split(" ");
        diaSemana.setText(separadorFecha[0]);
        diaNumero.setText(separadorFecha[1]);
        mes.setText(separadorFecha[2]);
        anyo.setText(separadorFecha[3]);



    }

    public static void main(String[] args) {
        new relojDigital();
    }

}